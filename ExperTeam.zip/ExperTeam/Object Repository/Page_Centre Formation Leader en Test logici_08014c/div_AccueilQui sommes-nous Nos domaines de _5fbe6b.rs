<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_AccueilQui sommes-nous Nos domaines de _5fbe6b</name>
   <tag></tag>
   <elementGuidId>13fec11a-87a3-4d62-8f53-026ac6d3ff67</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Top_bar']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#Top_bar</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>Top_bar</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

	
		
		
			
			
				
							
				
					Accueil
Qui sommes-nous ?
Nos domaines de Formation

	Tests de Logiciels
	Développement des Applications
	Ingénierie des Exigences
	Gestion de projets


Nos Cursus

	Testeur logiciel et automatisation
	Testeur Automaticien
	Développeur Full stack JS
	Développeur Applications Mobiles
	UX/UI Designer
	Marketing digital
	Responsable commerciale
	IT Acquisition Talent


Calendrier des formations
Demander un devis
Contactez-Nous
Blog

	Jeu Concours


					
							
				
				
					
									
				
				
									
				
				
					
					
					

						
		
	
	
	
				
	
	
					
								
				
			
			
						
		
	
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Top_bar&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='Top_bar']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='Header']/div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='commercial@expertunisie.com'])[1]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Besoin de savoir plus à propos d', &quot;'&quot;, 'une formation certifiante ?')])[1]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div[3]</value>
   </webElementXpaths>
</WebElementEntity>
