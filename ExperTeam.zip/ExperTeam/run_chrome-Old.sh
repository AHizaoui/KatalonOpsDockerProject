#!/usr/bin/env bash

set -xe

docker run -t --rm -v "$(pwd)":/katalon/katalon/source:ro katalonstudio/katalon katalon-execute.sh -browserType="Chrome" -headless -retry=0 -statusDelay=15 -testSuitePath="Test Suites/Headers"